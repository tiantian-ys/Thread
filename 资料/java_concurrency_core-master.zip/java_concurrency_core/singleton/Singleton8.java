package singleton;

/**
 * 描述：     枚举单例
 */
public enum Singleton8 {
    INSTANCE;

    public void whatever() {

    }
}
