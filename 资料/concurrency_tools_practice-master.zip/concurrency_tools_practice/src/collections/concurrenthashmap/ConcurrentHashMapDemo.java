package collections.concurrenthashmap;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 描述：     TODO
 */
public class ConcurrentHashMapDemo {
}
