package immutable;

/**
 * 描述：     演示final变量
 */
public class FinalVariableDemo {

    private static final Person person = null;

//    void testFinal() {
//       final int b = 7;
//        int c =b;
//    }
//    public FinalVariableDemo() {
//    }
//    public FinalVariableDemo(int a) {
////        this.a = a;
////    }
//
//    static {
//        a = 7;
//    }
}
